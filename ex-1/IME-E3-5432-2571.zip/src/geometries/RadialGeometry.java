package geometries;

public class RadialGeometry {
	double _radius;

	/******** constructor ********/
	public RadialGeometry(double _radius) {

		this._radius = _radius;
	}

	/******** getter ********/
	public double get_radius() {
		return _radius;
	}

}
