package geometries;


import primitives.*;

public interface Geometry extends Intersectable{
	/**
	 * Normalization of a vector
	 * 
	 * @param a
	 * @return abstract (normal)
	 */
	public abstract Vector getNormal();
	
}
