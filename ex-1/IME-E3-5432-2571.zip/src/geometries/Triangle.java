package geometries;

import java.util.ArrayList;
import java.util.List;

import primitives.*;

public class Triangle extends Polygon {

	// ***************** Constructors ********************** //
	/**
	 * @param points
	 * @param plane
	 */
	public Triangle(Point3D... points) {
		super(points);
	}

	// ***************** Operations ******************** //
	/**
	 * get normal function of triangle, we use in the plane's function
	 * 
	 * @param Point3D
	 * @return normal
	 */

	public Vector getNormal() {
		return this._plane.getNormal();
	}

	/**
	 * * @param ray
	 * 
	 * @return intersectionPoint
	 */
	public List<Point3D> findIntersections(Ray ray) {
		List<Point3D> intersectionPoint = new ArrayList<Point3D>();
		if (this._plane.findIntersections(ray) == null)// First, we check if the ray intersects the plane
			return null;
		Point3D p0 = ray.head;
		Point3D p1 = this._points.get(0);// triangle point
		Point3D p2 = this._points.get(1);// triangle point
		Point3D p3 = this._points.get(2);// triangle point
		Vector v1 = new Vector(p1.subtract(p0));// triangle vector(from one point to another)
		Vector v2 = new Vector(p2.subtract(p0));// triangle vector(from one point to another)
		Vector v3 = new Vector(p3.subtract(p0));// triangle vector(from one point to another)
		Vector n1 = new Vector(v1.crossProduct(v2));// vector normal
		Vector n2 = new Vector(v2.crossProduct(v3));// vector normal
		Vector n3 = new Vector(v3.crossProduct(v1));// vector normal

		if ((this._plane.findIntersections(ray).get(0).subtract(p0)).dotProduct(n1) > 0.0)// at the end, we are checking
																							// if all the points have
																							// the same sign
			if ((this._plane.findIntersections(ray).get(0).subtract(p0)).dotProduct(n2) > 0)
				if ((this._plane.findIntersections(ray).get(0).subtract(p0)).dotProduct(n3) > 0)
					return intersectionPoint;
		if ((this._plane.findIntersections(ray).get(0).subtract(p0)).dotProduct(n1) < -0.0)
			if ((this._plane.findIntersections(ray).get(0).subtract(p0)).dotProduct(n2) < 0)
				if ((this._plane.findIntersections(ray).get(0).subtract(p0)).dotProduct(n3) < 0)
					return intersectionPoint;
		return null;
	}

}
