package geometries;

import java.util.*;

public class Geometries {
	List<Intersectable> l;

//***************** Constructors ********************** //
	public Geometries(ArrayList<Intersectable> l) {
		super();
		this.l = l;
	}
public Geometries(Intersectable...geometries) {
	
}
//***************** Administration ******************** //
public void add(Intersectable...geometries) {
	
}

}
