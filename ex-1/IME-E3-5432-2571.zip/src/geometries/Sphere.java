package geometries;

import java.util.ArrayList;
import java.util.List;

import primitives.Ray;
import primitives.Vector;
import primitives.*;

public class Sphere extends RadialGeometry {
	Point3D _center;

	// ***************** Constructors ********************** //
	public Sphere(double _radius) {
		super(_radius);
	}

	public Sphere(double _radius, Point3D _center) {
		super(_radius);
		this._center = _center;
	}

	/****** getter *****/
	public Point3D get_center() {
		return _center;
	}

	// ***************** Operations ******************** //
	/**
	 * get normal function
	 * 
	 * @param p
	 * @return normal
	 */

	public Vector getNormal(Point3D p) {
		Vector v = new Vector(p.subtract(_center));// the normal vector
		return v.normalization();
	}

	/**
	 * 
	 * @param ray
	 * @return list of intersectionPoint
	 */
	public List<Point3D> findIntersections(Ray ray) {
		List<Point3D> intersectionPoint = new ArrayList<Point3D>();
		Point3D o = this._center;// center
		Point3D p0 = ray.head;
		if (p0.dictance(o) == 0) {
			Point3D p = p0.add(ray.v.scale(this._radius));// there is only one intersection point (on the sphere)
			intersectionPoint.add(p);
			return intersectionPoint;
		}
		Vector u = new Vector(o.subtract(p0));// vector from p0 to the center
		Vector v = new Vector(ray.v);
		double tm = v.dotProduct(u);// from p0, orthogonal to d
		double d = Math.sqrt(u.length2() - (tm * tm));// from the center to the ray
		if (d > this._radius)// there is not intersection point
			return null;
		double th = Math.sqrt((this._radius * this._radius) - (d * d));// from the cross point of d and tm until P1(the
																		// intersection point)
		double t1 = tm + th;// p1's scalar
		double t2 = tm - th;// p2's scalar
		if (t1 > 0) {// t>=0
			Point3D p1 = p0.add(ray.v.scale(t1));
			intersectionPoint.add(p1);
			if (t2 > 0) {// t>=0
				Point3D p2 = p0.add(ray.v.scale(t2));
				intersectionPoint.add(p2);
			}
			return intersectionPoint;
		}
		return null;

	}
}
