package geometries;

import java.util.ArrayList;
import java.util.List;

import primitives.*;

public class Plane implements Geometry {
	Point3D _p;
	Vector _normal;

	// ***************** Constructors ********************** //
	/**
	 * constructor of 3 points
	 * 
	 * @param _p1
	 * @param _p2
	 * @param _p3
	 */
	public Plane(Point3D _p1, Point3D _p2, Point3D _p3) {
		this._p = _p1;
		this._normal = _p2.subtract(_p1).crossProduct(_p3.subtract(_p1));
	}

	/**
	 * constructor with point and normal
	 * 
	 * @param _p
	 * @param _normal
	 */
	public Plane(Point3D _p, Vector _normal) {
		this._p = _p;
		this._normal = _normal.normalization();
	}

	// ***************** Operations ******************** //
	/**
	 * getNormal of a plane: The normal vector returns
	 * 
	 * @return normal
	 */

	public Vector getNormal() {
		return _normal;
	}
	/**
	 * @param ray
	 * @return list of intersectionPoint
	 * findIntersections of a plane
	 */
	public List<Point3D> findIntersections(Ray ray) {
		List<Point3D> intersectionPoint = new ArrayList<Point3D>();
		Vector n = this.getNormal();
		Point3D q0 = this._p;
		Point3D p0 = ray.head;
		
		if((p0.dictance(q0))==0) {
			intersectionPoint.add(p0);
			return intersectionPoint;
		}
		Vector v1 = new Vector(q0.subtract(p0));// q0-p0
		double up = n.dotProduct(v1);
		double d = n.dotProduct(ray.v);
		if (d == 0)// Parallel
			return null;
		double t = up / d;// if t<0 return null
		if (t == 0) {
			intersectionPoint.add(p0);
			return intersectionPoint;
		}
		Point3D p = p0.add(ray.v.scale(t));//normal cases of intersection
		intersectionPoint.add(p);
		return intersectionPoint;
	}
}
