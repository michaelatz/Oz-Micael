module targil1 {
	requires junit;
}