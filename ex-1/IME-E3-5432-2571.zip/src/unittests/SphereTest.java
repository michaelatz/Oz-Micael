package unittests;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import geometries.*;
import primitives.*;
public class SphereTest {

	@Test
	/**
	 * Test method for {@link geometries.Sphere#getNormal(primitives.Point3D)}.
	 */
	public void getNormaltest() {
		try {
			Point3D p1 = new Point3D(3.0, 0.0, 0.0);
			Point3D c = new Point3D(0.0, 0.0, 0.0);
			double r = 3.0;
			Sphere sph = new Sphere(r, c);
			Vector actual = sph.getNormal(p1);
			Vector expected = new Vector(1.0, 0.0, 0.0);
			Assert.assertEquals(expected, actual);
		} catch (Exception e) {
			Assert.fail("getNormaltest unxpected exception:" + e);
		}
	}

	@Test
	/**
	 * ray intersects the sphere(tow points)
	 */
	public void findIntersectionsTest1() {
		try {
			Point3D p0 = new Point3D(0, 0, 0);
			double radius = 1.0;
			Sphere s = new Sphere(radius, p0);
			Point3D p = new Point3D(-2, -1, 0);
			Vector v = new Vector(1, 1, 0);
			Ray ray = new Ray(v, p);
			List<Point3D> expected = new ArrayList<Point3D>();
			Point3D e1 = new Point3D(0, 1.0, 0);
			Point3D e2 = new Point3D(-1.0, 0, 0);
			expected.add(e1);
			expected.add(e2);
			List<Point3D> actual = s.findIntersections(ray);
			Assert.assertEquals(expected, actual);
		} catch (Exception e) {
			Assert.fail("findIntersectionsTest1 unxpected exception:" + e);
		}
	}

	@Test
	/**
	 * ray isn't intersects the sphere
	 */
	public void findIntersectionsTest2() {
		try {
			Point3D p0 = new Point3D(0, 0, 0);
			double radius = 1.0;
			Sphere s = new Sphere(radius, p0);
			Point3D p = new Point3D(-2, 0, 0);
			Vector v = new Vector(1, 2, 0);
			Ray ray = new Ray(v, p);
			List<Point3D> expected = null;
			List<Point3D> actual = s.findIntersections(ray);
			Assert.assertEquals(expected, actual);
		} catch (Exception e) {
			Assert.fail("findIntersectionsTest2 unxpected exception:" + e);
		}
	}

	@Test
	/**
	 * ray intersects the sphere(one point-starts on the sphere, pass in he center)
	 */
	public void findIntersectionsTest3() {
		try {
			Point3D p0 = new Point3D(0, 0, 0);
			double radius = 1.0;
			Sphere s = new Sphere(radius, p0);
			Point3D p = new Point3D(-1, 0, 0);
			Vector v = new Vector(1, 0, 0);
			Ray ray = new Ray(v, p);
			List<Point3D> expected = new ArrayList<Point3D>();
			Point3D e1 = new Point3D(1, 0, 0);
			expected.add(e1);
			List<Point3D> actual = s.findIntersections(ray);
			Assert.assertEquals(expected, actual);
		} catch (Exception e) {
			Assert.fail("findIntersectionsTest3 unxpected exception:" + e);
		}
	}
	@Test
	/**
	 * ray isn't intersects the sphere(Tangent)
	 */
	public void findIntersectionsTest4() {
		try {
			Point3D p0 = new Point3D(0, 0, 0);
			double radius = 1.0;
			Sphere s = new Sphere(radius, p0);
			Point3D p = new Point3D(-1.0, -1.0, 0);
			Vector v = new Vector(0, 1.0, 0);
			Ray ray = new Ray(v, p);
			List<Point3D> expected = null;
			List<Point3D> actual = s.findIntersections(ray);
			Assert.assertEquals(expected, actual);
		} catch (Exception e) {
			Assert.fail("findIntersectionsTest4 unxpected exception:" + e);
		}
	}

	@Test
	/**
	 * ray isn't intersects the sphere(Tangent-ray starts on the sphere)
	 */
	public void findIntersectionsTest5() {
		try {
			Point3D p0 = new Point3D(0, 0, 0);
			double radius = 1.0;
			Sphere s = new Sphere(radius, p0);
			Point3D p = new Point3D(-1, 0, 0);
			Vector v = new Vector(0, 1, 0);
			Ray ray = new Ray(v, p);
			List<Point3D> expected = null;
			List<Point3D> actual = s.findIntersections(ray);
			Assert.assertEquals(expected, actual);
		} catch (Exception e) {
			Assert.fail("findIntersectionsTest2 unxpected exception:" + e);
		}
	}

	@Test
	/**
	 * ray isn't intersects the sphere(orthogonal to the ray from the center-ray starts on that ray)
	 */
	public void findIntersectionsTest6() {
		try {
			Point3D p0 = new Point3D(0, 0, 0);
			double radius = 1.0;
			Sphere s = new Sphere(radius, p0);
			Point3D p = new Point3D(-2, 0, 0);
			Vector v = new Vector(0, 1, 0);
			Ray ray = new Ray(v, p);
			List<Point3D> expected = null;
			List<Point3D> actual = s.findIntersections(ray);
			Assert.assertEquals(expected, actual);
		} catch (Exception e) {
			Assert.fail("findIntersectionsTest2 unxpected exception:" + e);
		}
	}

	@Test
	/**
	 * ray intersects the sphere(one point-starts in the center of the sphere)
	 */
	public void findIntersectionsTest7() {
		try {
			Point3D p0 = new Point3D(0, 0, 0);
			double radius = 1.0;
			Sphere s = new Sphere(radius, p0);
			Point3D p = new Point3D(0, 0, 0);
			Vector v = new Vector(1, 0, 0);
			Ray ray = new Ray(v, p);
			List<Point3D> expected = new ArrayList<Point3D>();
			Point3D e1 = new Point3D(1, 0, 0);
			expected.add(e1);
			List<Point3D> actual = s.findIntersections(ray);
			Assert.assertEquals(expected, actual);
		} catch (Exception e) {
			Assert.fail("findIntersectionsTest7 unxpected exception:" + e);
		}
	}

	@Test
	/**
	 * ray intersects the sphere-starts behind the sphere(pass  the center)(tow points)
	 */
	public void findIntersectionsTest8() {
		try {
			Point3D p0 = new Point3D(0, 0, 0);
			double radius = 1.0;
			Sphere s = new Sphere(radius, p0);
			Point3D p = new Point3D(-2, 0, 0);
			Vector v = new Vector(1, 0, 0);
			Ray ray = new Ray(v, p);
			List<Point3D> expected = new ArrayList<Point3D>();
			Point3D e1 = new Point3D(1, 0., 0);
			Point3D e2 = new Point3D(-1, 0, 0);
			expected.add(e1);
			expected.add(e2);
			List<Point3D> actual = s.findIntersections(ray);
			Assert.assertEquals(expected, actual);
		} catch (Exception e) {
			Assert.fail("findIntersectionsTest1 unxpected exception:" + e);
		}
	}
	@Test
	/**
	 * ray intersects the sphere(tow points?) -ray starts in the opposite direction
	 */
	public void findIntersectionsTest9() {
		try {
			Point3D p0 = new Point3D(0, 0, 0);
			double radius = 1.0;
			Sphere s = new Sphere(radius, p0);
			Point3D p = new Point3D(-2, 0, 0);
			Vector v = new Vector(-3, -1, 0);
			Ray ray = new Ray(v, p);
			//List<Point3D> expected = new ArrayList<Point3D>();
			//Point3D e1 = new Point3D(-0.934846922835, 0.3550510257217, 0);
			//Point3D e2 = new Point3D(0.534846922835, 0.8449489742783, 0);
			//expected.add(e1);
			//expected.add(e2);
			List<Point3D> expected=null;
			List<Point3D> actual = s.findIntersections(ray);
			Assert.assertEquals(expected, actual);
		} catch (Exception e) {
			Assert.fail("findIntersectionsTest1 unxpected exception:" + e);
		}
	}	
	@Test
	/**
	 * ray intersects the sphere(one point) -ray starts inside! the sphere
	 */
	public void findIntersectionsTest10() {
		try {
			Point3D p0 = new Point3D(0, 0, 0);
			double radius = 1.0;
			Sphere s = new Sphere(radius, p0);
			Point3D p = new Point3D(-0.5, 0.5, 0);
			Vector v = new Vector(3, 1, 0);
			Ray ray = new Ray(v, p);
			List<Point3D> expected = new ArrayList<Point3D>();
			//Point3D e1 = new Point3D(-0.934846922835, 0.3550510257217, 0);
			Point3D e2 = new Point3D(0.534846922835, 0.8449489742783, 0);
			//expected.add(e1);
			expected.add(e2);
			List<Point3D> actual = s.findIntersections(ray);
			Assert.assertEquals(expected, actual);
		} catch (Exception e) {
			Assert.fail("findIntersectionsTest1 unxpected exception:" + e);
		}
	}
	@Test
	/**
	 * ray intersects the sphere(one point) -ray starts on! the sphere
	 */
	public void findIntersectionsTest11() {
		try {
			Point3D p0 = new Point3D(0, 0, 0);
			double radius = 1.0;
			Sphere s = new Sphere(radius, p0);
			Point3D p = new Point3D(-0.934846922835, 0.3550510257217, 0);
			Vector v = new Vector(3, 1, 0);
			Ray ray = new Ray(v, p);
			List<Point3D> expected = new ArrayList<Point3D>();
			//Point3D e1 = new Point3D(-0.934846922835, 0.3550510257217, 0);
			Point3D e2 = new Point3D(0.534846922835, 0.8449489742783, 0);
			//expected.add(e1);
			expected.add(e2);
			List<Point3D> actual = s.findIntersections(ray);
			Assert.assertEquals(expected, actual);
		} catch (Exception e) {
			Assert.fail("findIntersectionsTest11 unxpected exception:" + e);
		}
	}
	
	@Test
	/**
	 * ray intersects the sphere(one point) -ray starts on! the sphere, ray is in the opposite side
	 */
	public void findIntersectionsTest12() {
		try {
			Point3D p0 = new Point3D(0, 0, 0);
			double radius = 1.0;
			Sphere s = new Sphere(radius, p0);
			Point3D p = new Point3D(-0.934846922835, 0.3550510257217, 0);
			Vector v = new Vector(-3, -1, 0);
			Ray ray = new Ray(v, p);
			List<Point3D> expected =null;
			List<Point3D> actual = s.findIntersections(ray);
			Assert.assertEquals(expected, actual);
		} catch (Exception e) {
			Assert.fail("findIntersectionsTest1 unxpected exception:" + e);
		}
	}
	@Test
	/**
	 * ray isn't intersects the sphere(Tangent-ray starts after the sphere)
	 */
	public void findIntersectionsTest13() {
		try {
			Point3D p0 = new Point3D(0, 0, 0);
			double radius = 1.0;
			Sphere s = new Sphere(radius, p0);
			Point3D p = new Point3D(-1, 1, 0);
			Vector v = new Vector(0, 1, 0);
			Ray ray = new Ray(v, p);
			List<Point3D> expected = null;
			List<Point3D> actual = s.findIntersections(ray);
			Assert.assertEquals(expected, actual);
		} catch (Exception e) {
			Assert.fail("findIntersectionsTest2 unxpected exception:" + e);
		}
	}
	@Test
	/**
	 * ray isn't intersects the sphere(one point-starts on the sphere, pass in he center-opposite side)
	 */
	public void findIntersectionsTest14() {
		try {
			Point3D p0 = new Point3D(0, 0, 0);
			double radius = 1.0;
			Sphere s = new Sphere(radius, p0);
			Point3D p = new Point3D(-1, 0, 0);
			Vector v = new Vector(-1, 0, 0);
			Ray ray = new Ray(v, p);
			List<Point3D> expected=null;
			List<Point3D> actual = s.findIntersections(ray);
			Assert.assertEquals(expected, actual);
		} catch (Exception e) {
			Assert.fail("findIntersectionsTest3 unxpected exception:" + e);
		}
	}
	@Test
	/**
	 * ray isn't intersects the sphere(ray starts after the sphere- the opposite side of the ray passed the center)
	 */
	public void findIntersectionsTest15() {
		try {
			Point3D p0 = new Point3D(0, 0, 0);
			double radius = 1.0;
			Sphere s = new Sphere(radius, p0);
			Point3D p = new Point3D(-2, 0, 0);
			Vector v = new Vector(-1, 0, 0);
			Ray ray = new Ray(v, p);
			List<Point3D> expected = null;
			List<Point3D> actual = s.findIntersections(ray);
			Assert.assertEquals(expected, actual);
		} catch (Exception e) {
			Assert.fail("findIntersectionsTest2 unxpected exception:" + e);
		}
	}
	@Test
	/**
	 * ray  intersects the sphere(ray starts in the sphere- the opposite side of the ray passed the center)
	 */
	public void findIntersectionsTest16() {
		try {
			Point3D p0 = new Point3D(0, 0, 0);
			double radius = 1.0;
			Sphere s = new Sphere(radius, p0);
			Point3D p = new Point3D(-0.5, 0, 0);
			Vector v = new Vector(-1, 0, 0);
			Ray ray = new Ray(v, p);
			List<Point3D> expected = new ArrayList<Point3D>();
			Point3D e2 = new Point3D(-1, 0, 0);
			expected.add(e2);
			List<Point3D> actual = s.findIntersections(ray);
			Assert.assertEquals(expected, actual);
		} catch (Exception e) {
			Assert.fail("findIntersectionsTest2 unxpected exception:" + e);
		}
	}@Test
	/**
	 * ray  intersects the sphere(ray starts in the sphere- ray passed the center)
	 */
	public void findIntersectionsTest17() {
		try {
			Point3D p0 = new Point3D(0, 0, 0);
			double radius = 1.0;
			Sphere s = new Sphere(radius, p0);
			Point3D p = new Point3D(0.5, 0, 0);
			Vector v = new Vector(-1, 0, 0);
			Ray ray = new Ray(v, p);
			List<Point3D> expected = new ArrayList<Point3D>();
			Point3D e2 = new Point3D(-1, 0, 0);
			expected.add(e2);
			List<Point3D> actual = s.findIntersections(ray);
			Assert.assertEquals(expected, actual);
		} catch (Exception e) {
			Assert.fail("findIntersectionsTest2 unxpected exception:" + e);
		}
	}
	
}
