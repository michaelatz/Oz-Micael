package unittests;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;

import primitives.*;

public class VectorTest {

	/**
	 * test Method for {@link primitives.Vector#Zero(primitives.Vector)}.
	 */
	@Test
	public void testVectorZero() {

		try {
			Point3D p = new Point3D(Coordinate.ZERO, Coordinate.ZERO, Coordinate.ZERO);
			Vector myVector = new Vector(new Point3D(Coordinate.ZERO, Coordinate.ZERO, Coordinate.ZERO));
			Assert.assertNotEquals(myVector, p);
			Assert.fail("Test failed should throw excepion");
		} catch (IllegalArgumentException e) {
			Assert.assertTrue("Test PASS  throw excepion in case of Zero", true);

		}

	}

	/**
	 * test Method for {@link primitives.Vector#add(primitives.Vector)}.
	 */
	@Test
	public void testAddition() {
		try {
			Vector myVector = new Vector(1.0, 2.0, 3.0);
			Vector other = new Vector(1.0, 1.0, 1.0);
			Vector expected = new Vector(2.0, 3.0, 4.0);
			Vector actual = myVector.add(other);
			Assert.assertEquals(expected, actual);

		} catch (Exception e) {
			Assert.fail("testAddition unxpected exception:" + e);
		}

	}

	/**
	 * test Method for {@link primitives.Vector#subtract(primitives.Vector)}.
	 */
	@Test
	public void testSubtract() {
		try {
			Vector myVector = new Vector(1.0, 2.0, 3.0);
			Vector other = new Vector(1.0, 1.0, 1.0);
			Vector expected = new Vector(0.0, 1.0, 2.0);
			Vector actual = myVector.subtract(other);
			Assert.assertEquals(expected, actual);

		} catch (Exception e) {
			Assert.fail("test Subtract fail unxpected exception:" + e);
		}

	}

	/**
	 * test Method for {@link primitives.Vector#scale(primitives.Vector)}.
	 */
	@Test
	public void testScale() {
		try {
			Vector myVector = new Vector(1.0, 2.0, 3.0);
			double a = 2.0;
			Vector expected = new Vector(2.0, 4.0, 6.0);
			Vector actual = myVector.scale(a);
			Assert.assertEquals(expected, actual);

		} catch (Exception e) {
			Assert.fail("test Scale fail unxpected exception:" + e);
		}
	}

	/**
	 * test Method for {@link primitives.Vector#dotProduct(primitives.Vector)}.
	 */
	@Test
	public void testDotProduct() {
		try {
			Vector myVector = new Vector(1.0, 2.0, 3.0);
			Vector other = new Vector(1.0, 1.0, 1.0);
			double expected = 6.0;
			double actual = myVector.dotProduct(other);
			Assert.assertEquals(expected, actual, 0.0);
		} catch (Exception e) {
			Assert.fail("test DotProduct fail unxpected exception:" + e);
		}
	}

	/**
	 * test Method for {@link primitives.Vector#crossProduct(primitives.Vector)}.
	 */
	@Test
	public void testCrossProduct() {
		try {
			Vector myVector = new Vector(1.0, 2.0, 3.0);
			Vector other = new Vector(1.0, 1.0, 1.0);
			Vector expected = new Vector(-1, 2, -1);

			Vector result = myVector.crossProduct(other);
			Assert.assertEquals(expected, result);
		} catch (Exception e) {
			Assert.fail("test CrossProduct fail unxpected exception:" + e);
		}
	}

	/**
	 * test Method for {@link primitives.Vector#normalization(primitives.Vector)}.
	 */
	@Test
	public void testNormal() {
		try {
			Vector myVector = new Vector(1.0, 2.0, 2.0);
			Vector expected = new Vector((double) 1 / 3, (double) 2 / 3, ((double) 2 / 3));

			Vector result = myVector.normalization();
			Assert.assertEquals(expected, result);
		} catch (Exception e) {
			Assert.fail("test CrossProduct fail unxpected exception:" + e);
		}
	}
}
