package unittests;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;

import geometries.*;
import primitives.*;

public class CylinderTest {

	@Test
	/**
	 * Test method for {@link geometries.Cylinder#getNormal(primitives.Point3D)}.
	 */
	public void getNormaltest1() {
		try {
			Point3D p1 = new Point3D(0.0, 0.0, 0.0);
			Point3D p2 = new Point3D(0.0, 10.0, 4.0);
			Vector vec = new Vector(0.0, 0.0, 1.0);
			Ray ray = new Ray(vec, p1);
			double h = 10.0;
			double r = 10.0;
			Cylinder cy = new Cylinder(r, ray, h);
			Vector actual = cy.getNormal(p2);
			Vector expected = new Vector(0.0, 1.0, 0.0);
			Assert.assertEquals(expected, actual);
		} catch (Exception e) {
			Assert.fail("getNormaltest unxpected exception:" + e);
		}
	}

	@Test
	/**
	 * Test method for {@link geometries.Cylinder#getNormal(primitives.Point3D)}.
	 */
	public void getNormaltest2() {
		try {
			Point3D p1 = new Point3D(0.0, 0.0, 0.0);
			Point3D p2 = new Point3D(1.0, 0.0, 0.0);
			Point3D p3 = new Point3D(3.0, 1.0, 0.0);
			Vector vec = new Vector(p2);
			Ray ray = new Ray(vec, p1);
			double h = 5.0;
			double r = 3.0;
			Cylinder cy = new Cylinder(r, ray, h);
			Vector actual = cy.getNormal(p3);
			Vector expected = new Vector(0.0, 1.0, 0.0);
			Assert.assertEquals(expected, actual);
		} catch (Exception e) {
			Assert.fail("getNormaltest unxpected exception:" + e);
		}
	}

	public void findIntersectionsTest() {

	}

}
