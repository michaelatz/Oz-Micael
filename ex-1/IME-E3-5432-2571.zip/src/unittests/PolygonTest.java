package unittests;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import geometries.*;
import primitives.*;

public class PolygonTest {

	/**
	 * Test method for {@link geometries.Triangle#getNormal(primitives.Point3D)}.
	 */
	@Test
	public void getNormaltest() {
		try {
			Point3D p1 = new Point3D(1.0, 0.0, 0.0);
			Point3D p2 = new Point3D(1.0, 1.0, 1.0);
			Point3D p3 = new Point3D(0.0, 1.0, 1.0);
			Point3D p4 = new Point3D(2.0, 1.0, 1.0);
			Polygon polygon = new Polygon(p1, p2, p3, p4);
			Vector actual = polygon.getNormal();
			Vector expected = new Vector(0.0, -1.0, 1.0);
			Assert.assertEquals(expected, actual);
		} catch (Exception e) {
			Assert.fail("getNormaltest unxpected exception:" + e);
		}
	}

	@Test
	/**
	 * ray intersects and orthogonal to the plane
	 */
	public void findIntersectionsTest1() {
		try {
			Point3D p1 = new Point3D(2, 0, 0);
			Point3D p2 = new Point3D(-2, 0, 0);
			Point3D p3 = new Point3D(0, 2, 0);
			Point3D p4 = new Point3D(0, -2, 0);
			Polygon po=new Polygon(p1,p2,p3,p4);
			Plane pl = new Plane(p1, p2, p3);
			Vector v = new Vector(0, 0, 1);
			Point3D p0 = new Point3D(0, 0, -1);
			Ray r = new Ray(v, p0);
			List<Point3D> expected = new ArrayList<Point3D>();
			Point3D e = new Point3D(0, 0, 0);
			expected.add(e);
			List<Point3D> actual = pl.findIntersections(r);
			Assert.assertEquals(expected, actual);
		} catch (Exception e) {
			Assert.fail("findIntersectionsTest1 unxpected exception:" + e);
		}

	}

	@Test
	/**
	 * ray intersects the plane (not orthogonal)
	 */
	public void findIntersectionsTest2() {
		try {
			Vector v = new Vector(1, 1, 1);
			Point3D p0 = new Point3D(-1, -1, -1);
			Ray r = new Ray(v, p0);
			Point3D p1 = new Point3D(2, 0, 0);
			Point3D p2 = new Point3D(-2, 0, 0);
			Point3D p3 = new Point3D(0, 2, 0);
			Point3D p4 = new Point3D(0, -2, 0);
			Polygon po=new Polygon(p1,p2,p3,p4);
			Plane pl = new Plane(p1, p2, p3);
			List<Point3D> expected = new ArrayList<Point3D>();
			Point3D e = new Point3D(0, 0, 0);
			expected.add(e);
			List<Point3D> actual = pl.findIntersections(r);
			Assert.assertEquals(expected, actual);
		} catch (Exception e) {
			Assert.fail("findIntersectionsTest2 unxpected exception:" + e);
		}

	}

	@Test
	/**
	 * ray parallel (not included in the plane)
	 */
	public void findIntersectionsTest3() {
		try {
			Vector v = new Vector(1, 0, 0);
			Point3D p0 = new Point3D(0, 0, -1);
			Ray r = new Ray(v, p0);
			Point3D p1 = new Point3D(2, 0, 0);
			Point3D p2 = new Point3D(-2, 0, 0);
			Point3D p3 = new Point3D(0, 2, 0);
			Point3D p4 = new Point3D(0, -2, 0);
			Polygon po=new Polygon(p1,p2,p3,p4);
			Plane pl = new Plane(p1, p2, p3);
			List<Point3D> expected = null;
			List<Point3D> actual = pl.findIntersections(r);
			Assert.assertEquals(expected, actual);
		} catch (Exception e) {
			Assert.fail("findIntersectionsTest2 unxpected exception:" + e);
		}

	}

	@Test
	/**
	 * ray parallel (included in the plane)
	 */
	public void findIntersectionsTest4() {
		try {
			Vector v = new Vector(1, 0, 0);
			Point3D p0 = new Point3D(0, 0, 0);
			Ray r = new Ray(v, p0);
			Point3D p1 = new Point3D(2, 0, 0);
			Point3D p2 = new Point3D(-2, 0, 0);
			Point3D p3 = new Point3D(0, 2, 0);
			Point3D p4 = new Point3D(0, -2, 0);
			Polygon po=new Polygon(p1,p2,p3,p4);
			Plane pl = new Plane(p1, p2, p3);
			List<Point3D> expected = null;
			List<Point3D> actual = pl.findIntersections(r);
			Assert.assertEquals(expected, actual);
		} catch (Exception e) {
			Assert.fail("findIntersectionsTest2 unxpected exception:" + e);
		}
	}

	@Test
	/**
	 * ray intersects and orthogonal the plane(begins in the plane)
	 */
	public void findIntersectionsTest5() {
		try {
			Vector v = new Vector(0, 0, 1);
			Point3D p0 = new Point3D(0, 0, 0);
			Ray r = new Ray(v, p0);
			Point3D p1 = new Point3D(2, 0, 0);
			Point3D p2 = new Point3D(-2, 0, 0);
			Point3D p3 = new Point3D(0, 2, 0);
			Point3D p4 = new Point3D(0, -2, 0);
			Polygon po=new Polygon(p1,p2,p3,p4);
			Plane pl = new Plane(p1, p2, p3);
			List<Point3D> expected = new ArrayList<Point3D>();
			Point3D e = new Point3D(0, 0, 0);
			expected.add(e);
			List<Point3D> actual = pl.findIntersections(r);
			Assert.assertEquals(expected, actual);
		} catch (Exception e) {
			Assert.fail("findIntersectionsTest2 unxpected exception:" + e);
		}
	}

	@Test
	public void findIntersectionsTest6() {
		try {
			Vector v = new Vector(1, 1, 1);
			Point3D p0 = new Point3D(0, 0, 0);
			Ray r = new Ray(v, p0);
			Point3D p1 = new Point3D(2, 0, 0);
			Point3D p2 = new Point3D(-2, 0, 0);
			Point3D p3 = new Point3D(0, 2, 0);
			Point3D p4 = new Point3D(0, -2, 0);
			Polygon po=new Polygon(p1,p2,p3,p4);
			Plane pl = new Plane(p1, p2, p3);
			List<Point3D> expected = new ArrayList<Point3D>();
			Point3D e = new Point3D(0, 0, 0);
			expected.add(e);
			List<Point3D> actual = pl.findIntersections(r);
			Assert.assertEquals(expected, actual);
		} catch (Exception e) {
			Assert.fail("findIntersectionsTest2 unxpected exception:" + e);
		}
	}

	@Test
	public void findIntersectionsTest7() {
		try {
			Vector v = new Vector(1, 1, 1);
			Point3D p0 = new Point3D(1, 0, 0);
			Ray r = new Ray(v, p0);
			Point3D p1 = new Point3D(2, 0, 0);
			Point3D p2 = new Point3D(-2, 0, 0);
			Point3D p3 = new Point3D(0, 2, 0);
			Point3D p4 = new Point3D(0, -2, 0);
			Polygon po=new Polygon(p1,p2,p3,p4);
			Plane pl = new Plane(p1, p2, p3);
			List<Point3D> expected = new ArrayList<Point3D>();
			Point3D e = new Point3D(1, 0, 0);
			expected.add(e);
			List<Point3D> actual = pl.findIntersections(r);
			Assert.assertEquals(expected, actual);
		} catch (Exception e) {
			Assert.fail("findIntersectionsTest2 unxpected exception:" + e);
		}
	}

}
