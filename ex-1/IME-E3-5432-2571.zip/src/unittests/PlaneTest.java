package unittests;

import static org.junit.Assert.*;

import java.util.*;

import org.junit.Assert;
import org.junit.Test;
import geometries.*;
import primitives.*;
import primitives.Vector;

public class PlaneTest {

	@Test
	/**
	 * Test method for {@link geometries.Plane#getNormal(primitives.Point3D)}.
	 */
	public void getNormaltest() {
		try {
			Point3D p1 = new Point3D(1.0, 0.0, 0.0);
			Point3D p2 = new Point3D(1.0, 1.0, 1.0);
			Point3D p3 = new Point3D(0.0, 1.0, 1.0);
			Plane plane = new Plane(p1, p2, p3);
			Vector actual = plane.getNormal();
			Vector expected = new Vector(0.0, -1.0, 1.0);
			Assert.assertEquals(expected, actual);
		} catch (Exception e) {
			Assert.fail("getNormaltest unxpected exception:" + e);
		}
	}

	@Test
	/**
	 * ray intersects and orthogonal to the plane
	 */
	public void findIntersectionsTest1() {
		try {
			Vector v = new Vector(0, 0, 1);
			Point3D p0 = new Point3D(0, 0, -1);
			Ray r = new Ray(v, p0);
			Point3D p1 = new Point3D(1, 0, 0);
			Point3D p2 = new Point3D(1, 1, 0);
			Point3D p3 = new Point3D(0, 1, 0);
			Plane pl = new Plane(p1, p2, p3);
			List<Point3D> expected = new ArrayList<Point3D>();
			Point3D e = new Point3D(0, 0, 0);
			expected.add(e);
			List<Point3D> actual = pl.findIntersections(r);
			Assert.assertEquals(expected, actual);
		} catch (Exception e) {
			Assert.fail("findIntersectionsTest1 unxpected exception:" + e);
		}

	}

	@Test
	/**
	 * ray intersects the plane (not orthogonal)
	 */
	public void findIntersectionsTest2() {
		try {
			Vector v = new Vector(1, 1, 1);
			Point3D p0 = new Point3D(-1, -1, -1);
			Ray r = new Ray(v, p0);
			Point3D p1 = new Point3D(1, 0, 0);
			Point3D p2 = new Point3D(1, 1, 0);
			Point3D p3 = new Point3D(0, 1, 0);
			Plane pl = new Plane(p1, p2, p3);
			List<Point3D> expected = new ArrayList<Point3D>();
			Point3D e = new Point3D(0, 0, 0);
			expected.add(e);
			List<Point3D> actual = pl.findIntersections(r);
			Assert.assertEquals(expected, actual);
		} catch (Exception e) {
			Assert.fail("findIntersectionsTest2 unxpected exception:" + e);
		}

	}

	@Test
	/**
	 * ray parallel (not included in the plane)
	 */
	public void findIntersectionsTest3() {
		try {
			Vector v = new Vector(1, 0, 0);
			Point3D p0 = new Point3D(0, 0, -1);
			Ray r = new Ray(v, p0);
			Point3D p1 = new Point3D(1, 0, 0);
			Point3D p2 = new Point3D(1, 1, 0);
			Point3D p3 = new Point3D(0, 1, 0);
			Plane pl = new Plane(p1, p2, p3);
			List<Point3D> expected = null;
			List<Point3D> actual = pl.findIntersections(r);
			Assert.assertEquals(expected, actual);
		} catch (Exception e) {
			Assert.fail("findIntersectionsTest2 unxpected exception:" + e);
		}

	}

	@Test
	/**
	 * ray parallel (included in the plane)
	 */
	public void findIntersectionsTest4() {
		try {
			Vector v = new Vector(1, 0, 0);
			Point3D p0 = new Point3D(0, 0, 0);
			Ray r = new Ray(v, p0);
			Point3D p1 = new Point3D(1, 0, 0);
			Point3D p2 = new Point3D(1, 1, 0);
			Point3D p3 = new Point3D(0, 1, 0);
			Plane pl = new Plane(p1, p2, p3);
			List<Point3D> expected = null;
			List<Point3D> actual = pl.findIntersections(r);
			Assert.assertEquals(expected, actual);
		} catch (Exception e) {
			Assert.fail("findIntersectionsTest2 unxpected exception:" + e);
		}
	}

	@Test
	/**
	 * ray intersects and orthogonal the plane(begins in the plane)
	 */
	public void findIntersectionsTest5() {
		try {
			Vector v = new Vector(0, 0, 1);
			Point3D p0 = new Point3D(0, 0, 0);
			Ray r = new Ray(v, p0);
			Point3D p1 = new Point3D(1, 0, 0);
			Point3D p2 = new Point3D(1, 1, 0);
			Point3D p3 = new Point3D(0, 1, 0);
			Plane pl = new Plane(p1, p2, p3);
			List<Point3D> expected = new ArrayList<Point3D>();
			Point3D e = new Point3D(0, 0, 0);
			expected.add(e);
			List<Point3D> actual = pl.findIntersections(r);
			Assert.assertEquals(expected, actual);
		} catch (Exception e) {
			Assert.fail("findIntersectionsTest2 unxpected exception:" + e);
		}
	}

	@Test
	/**
	 * ray begins on the plane (one point)
	 */
	public void findIntersectionsTest6() {
		try {
			Vector v = new Vector(1, 1, 1);
			Point3D p0 = new Point3D(0, 0, 0);
			Ray r = new Ray(v, p0);
			Point3D p1 = new Point3D(1, 0, 0);
			Point3D p2 = new Point3D(1, 1, 0);
			Point3D p3 = new Point3D(0, 1, 0);
			Plane pl = new Plane(p1, p2, p3);
			List<Point3D> expected = new ArrayList<Point3D>();
			Point3D e = new Point3D(0, 0, 0);
			expected.add(e);
			List<Point3D> actual = pl.findIntersections(r);
			Assert.assertEquals(expected, actual);
		} catch (Exception e) {
			Assert.fail("findIntersectionsTest6 unxpected exception:" + e);
		}
	}

	@Test
	/**
	 * ray begins in the same point which appears a reference point on the plane(one
	 * point)
	 */
	public void findIntersectionsTest7() {
		try {
			Vector v = new Vector(1, 1, 1);
			Point3D p0 = new Point3D(1, 0, 0);
			Ray r = new Ray(v, p0);
			Point3D p1 = new Point3D(1, 0, 0);
			Point3D p2 = new Point3D(1, 1, 0);
			Point3D p3 = new Point3D(0, 1, 0);
			Plane pl = new Plane(p1, p2, p3);
			List<Point3D> expected = new ArrayList<Point3D>();
			Point3D e = new Point3D(1, 0, 0);
			expected.add(e);
			List<Point3D> actual = pl.findIntersections(r);
			Assert.assertEquals(expected, actual);
		} catch (Exception e) {
			Assert.fail("findIntersectionsTest7 unxpected exception:" + e);
		}
	}

	@Test
	/**
	 * ray begins after the the plane (one point or doesn't intersects)
	 */
	public void findIntersectionsTest8() {
		try {
			Vector v = new Vector(0, 0, 1);
			Point3D p0 = new Point3D(0, 0, 1);
			Ray r = new Ray(v, p0);
			Point3D p1 = new Point3D(1, 0, 0);
			Point3D p2 = new Point3D(1, 1, 0);
			Point3D p3 = new Point3D(0, 1, 0);
			Plane pl = new Plane(p1, p2, p3);
			 List<Point3D> expected = new ArrayList<Point3D>();
			 Point3D e = new Point3D(0, 0, 0);
			 expected.add(e);
			//List<Point3D> expected = null;
			List<Point3D> actual = pl.findIntersections(r);
			Assert.assertEquals(expected, actual);
		} catch (Exception e) {
			Assert.fail("findIntersectionsTest7 unxpected exception:" + e);
		}
	}

}
