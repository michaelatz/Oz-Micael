
package primitives;

/**
 * Point3D class
 */
public class Point3D {
	private Coordinate x;
	private Coordinate y;
	private Coordinate z;

	public static Point3D ZERO = new Point3D(Coordinate.ZERO, Coordinate.ZERO, Coordinate.ZERO);

	// ***************** Constructors ********************** //
	/**
	 * Constructor with Coordinate
	 * 
	 * @param x
	 * @param y
	 * @param z
	 */
	public Point3D(Coordinate x, Coordinate y, Coordinate z) {
		this.x = x;
		this.y = y;
		this.z = z;
	}

	/**
	 * Constructor with double
	 * 
	 * @param x
	 * @param y
	 * @param z
	 */

	public Point3D(double x, double y, double z) {
		Coordinate c1 = new Coordinate(x);
		Coordinate c2 = new Coordinate(y);
		Coordinate c3 = new Coordinate(z);
		this.x = c1;
		this.y = c2;
		this.z = c3;
	}

	/**
	 * Copy constructor
	 * 
	 * @param point
	 */
	public Point3D(Point3D point) {
		this.x = point.x;
		this.y = point.y;
		this.z = point.z;
	}

	// ***************** Getters/Setters ********************** //
	/**
	 * @return the x
	 */

	public Coordinate getX() {
		return x;
	}

	/**
	 * @return the y
	 */
	public Coordinate getY() {
		return y;
	}

	/**
	 * @return the z
	 */
	public Coordinate getZ() {
		return z;
	}

	// ***************** Administration ******************** //
	@Override
	public String toString() {
		return ("x:" + x + " y:" + y + " z:" + z);
	}

	@Override
	public boolean equals(Object other) {
		if (this.getClass() == other.getClass()) {
			Point3D obj = (Point3D) other;
			if (x.equals(obj.getX()) && y.equals(obj.getY()) && z.equals(obj.getZ())) {

				return true;
			}
		}
		return false;
	}
	// ***************** Operations ******************** //

	/**
	 * Subtract function
	 * 
	 * @param a
	 * @return Vector
	 */
	public Vector subtract(Point3D other) {
		double x1 = this.x.get();
		double y1 = this.y.get();
		double z1 = this.z.get();
		double x2 = other.x.get();
		double y2 = other.y.get();
		double z2 = other.z.get();
		return new Vector(x1 - x2, y1 - y2, z1 - z2);
	}

	/**
	 * Adding function
	 * 
	 * @param a
	 * @return Point3D
	 */
	public Point3D add(Vector a) {
		Point3D temp;
		temp = new Point3D(this.getX().add(a.getHead().getX()), this.getY().add(a.getHead().getY()),
				this.getZ().add(a.getHead().getZ()));
		return temp;
	}

	/**
	 * Calculate the distance at square((x2-x1)^2+(y2-y1)^2+(z2-z1)^2)
	 * 
	 * @param a Point3D parameter
	 * @return double
	 */

	public double distance2(Point3D a) {
		double temp;
		double s1;
		s1 = this.getX().subtract(a.getX()).get();
		temp = s1 * s1;
		s1 = this.getY().subtract(a.getY()).get();
		temp = temp + s1 * s1;
		s1 = this.getZ().subtract(a.getZ()).get();
		temp = temp + s1 * s1;

		return temp;
	}

	/**
	 * Calculate the distance root of ((x2-x1)^2+(y2-y1)^2+(z2-z1)^2)
	 * 
	 * @param a
	 * @return double
	 */

	public double dictance(Point3D a) {
		return Math.sqrt(this.distance2(a));
	}

}
