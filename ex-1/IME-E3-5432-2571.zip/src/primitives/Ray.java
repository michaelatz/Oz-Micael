package primitives;

public class Ray {
	public Point3D head;
	public Vector v;

	// ***************** Constructors ********************** //
	/**
	 * Constructor of ray
	 * 
	 * @param vec
	 * @param p
	 */
	public Ray(Vector vec, Point3D p) {

		this.v = vec.normalization();
		this.head = p;
	}

	/**
	 * @param r
	 */
	public Ray(Ray r) {
		head = r.head;
		v = r.v;
	}

	// ***************** Getters/Setters ********************** //
	/**
	 * @return head
	 */
	public Point3D getHead() {
		return head;
	}

	/**
	 * @return v
	 */
	public Vector getV() {
		return v;
	}

	// ***************** Administration ******************** //
	@Override
	public String toString() {
		return "Ray [" + head + ", " + v + "]";
	}

	@Override
	public boolean equals(Object other) {
		if (head.equals(other) == true) {
			if (v.equals(other) == true) {
				return true;
			}
		}
		return false;
	}

}
