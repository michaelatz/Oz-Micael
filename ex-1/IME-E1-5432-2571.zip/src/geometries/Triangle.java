package geometries;
import primitives.Point3D;
import primitives.Vector;

public class Triangle {
Plane _plane;
Point3D _p1;
Point3D _p2;
Point3D _p3;
//constructors
public Triangle(Plane _plane, Point3D _p1, Point3D _p2, Point3D _p3) {
	super();
	this._plane = _plane;
	this._p1 = _p1;
	this._p2 = _p2;
	this._p3 = _p3;
}
//getters
public Plane get_plane() {
	return _plane;
}

public Point3D get_p1() {
	return _p1;
}

public Point3D get_p2() {
	return _p2;
}

public Point3D get_p3() {
	return _p3;
}
//Normalization of a vector	
Vector getNormal(Point3D a) {
	return _plane.getNormal(a);
}
}
