package geometries;

public class RadialGeometry {
double _radius;

public RadialGeometry(double _radius) {
	super();
	this._radius = _radius;
}

public double get_radius() {
	return _radius;
}


}
