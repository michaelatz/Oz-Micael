package geometries;

import java.util.List;

import primitives.Point3D;

public abstract class Polygon {
List<Point3D>_points;
Plane _plane;
//constructor
public Polygon(List<Point3D> _points, Plane _plane) {
	super();
	this._points = _points;
	this._plane = _plane;
}
//getters
public List<Point3D> get_points() {
	return _points;
}
public Plane get_plane() {
	return _plane;
}


}
