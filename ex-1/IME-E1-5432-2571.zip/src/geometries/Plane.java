package geometries;

import primitives.Point3D;
import primitives.Vector;

public class Plane {
Point3D _p;
Vector _normal;
//constructor
public Plane(Point3D point, Vector normal) {
	super();
	this._p = point;
	this._normal = normal;
}
//getters
public Point3D getPoint() {
	return _p;
}

public Vector getNormal() {
	return _normal;
}
Vector getNormal(Point3D p) {
return null;
}
}
