package geometries;
import primitives.Point3D;
import primitives.Ray;
import primitives.Vector;

public class Tube extends RadialGeometry {
protected Ray _axisRay;
//constructors
public Tube(double _radius) {
		super(_radius);
		
	}

//getter
public Ray get_axisRay() {
	return _axisRay;
}
//Normalization of a vector	
Vector getNormal(Point3D a) {
return null;
}

}
