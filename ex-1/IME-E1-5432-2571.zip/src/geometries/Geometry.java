package geometries;

import primitives.Point3D;
import primitives.*;

public interface Geometry {
	//Normalization of a vector	
public abstract Vector getNormal(Point3D a);

}
