package geometries;

import primitives.Point3D;
import primitives.Vector;

public class Cylinder extends Tube{
double _hight;
//constructors
	public Cylinder(double _radius) {
		super(_radius);
		
	}
	public Cylinder(double _radius, double _hight) {
		super(_radius);
		this._hight = _hight;
	}
//getter
	public double get_hight() {
		return _hight;
	}
//Normalization of a vector	
Vector getNormal(Point3D a) {
		return null;
	}
}
