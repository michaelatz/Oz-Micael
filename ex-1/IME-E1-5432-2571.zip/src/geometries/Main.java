package geometries;
import primitives.*;

public class Main {

	public static void main(String[] args) {
		testVector();
		
		}
	
	public static void testVector() {
		//test construct of zero vec
		try {
			
			Vector v= new Vector(Vector.ZeroVec);
			System.out.println("Test failed should throw excepion");
		}
		catch (IllegalArgumentException e) {
			System.out.println("Test PASS  throw excepion in case of Zero");

		}
		// test subtract v - v should be ZeroVec
		try {
			Vector v = new Vector(new Point3D(new Coordinate(1.0),new Coordinate(2.0),new Coordinate(3.0)));
			Vector result = v.subtraction(v, v);
			if (result.equals(Vector.ZeroVec))
				System.out.println("Test PASS");
			else System.out.println("Test FAI");
		}
		catch (Exception e) {
			System.out.println("Test FAIL");

		}
		//normal and dotProduct is correct
		try {
			Vector v = new Vector(new Point3D(new Coordinate(1.0),new Coordinate(2.0),new Coordinate(2.0)));
			Vector norm = v.Normal(v);
			double result=v.dotProduct(v,norm);
			if (result==3)
				System.out.println("normal and dotProduct is correct:Test PASS");
			else System.out.println("normal and dotProduct is correct:Test FAIL");
		}
		catch (Exception e) {
			System.out.println("normal and dotProduct:Test FAIL");

		}
		//Scaling is correct
		try {
			Vector v = new Vector(new Point3D(new Coordinate(1.0),new Coordinate(2.0),new Coordinate(3.0)));
			double n=2;
			Vector result=v.Scaling(v,n);
			if (result.equals(new Vector(new Point3D(new Coordinate(2.0),new Coordinate(4.0),new Coordinate(6.0)))))
				System.out.println("Scaling is correct:Test PASS");
			else System.out.println("Scaling is correct:Test FAIL");
		}
		catch (Exception e) {
			System.out.println("Scaling is correct:Test FAIL");

		}
		//length is correct
		try {
			Vector v = new Vector(new Point3D(new Coordinate(1.0),new Coordinate(2.0),new Coordinate(2.0)));
			double result=v.length(v);
			if (result==3)
				System.out.println("length:Test PASS");
			else System.out.println("length:Test FAIL");
		}
		catch (Exception e) {
			System.out.println("length:Test FAIL");

		}
		//cross product is correct
		try {
			Vector v1 = new Vector(new Point3D(new Coordinate(1.0),new Coordinate(2.0),new Coordinate(3.0)));
			Vector v2 = new Vector(new Point3D(new Coordinate(1.0),new Coordinate(1.0),new Coordinate(1.0)));
			Vector result=v1.crossProduct(v1,v2);
			if (result.equals(new Vector(new Point3D(new Coordinate(-1.0),new Coordinate(2.0),new Coordinate(-1.0)))))
				System.out.println("cross product is correct:Test PASS");
			else System.out.println("cross product is correct:Test FAIL");
		}
		catch (Exception e) {
			System.out.println("cross product is correct:Test FAIL");

		}
	}
		
		
	}
		

		
		
	


