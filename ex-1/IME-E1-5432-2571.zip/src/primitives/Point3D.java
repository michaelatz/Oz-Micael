package primitives;

public class Point3D {
static Point3D zeroPd = new Point3D(Coordinate.ZERO,Coordinate.ZERO,Coordinate.ZERO);

Coordinate x;
Coordinate y;
Coordinate z;
//constructors
public Point3D(Point3D a) {
	x=a.x;
	y=a.y;
	z=a.z;
}
public Point3D(Coordinate x, Coordinate y, Coordinate z) {
	super();
	this.x = x;
	this.y = y;
	this.z = z;
}


//getters
public Coordinate getX() {
	return x;
}
public Coordinate getY() {
	return y;
}
public Coordinate getZ() {
	return z;
}

@Override
public String toString() {
	return "Point3D [x=" + x + ", y=" + y + ", z=" + z + "]";
}

//equals
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Point3D other = (Point3D) obj;
	if (x == null) {
		if (other.x != null)
			return false;
	} else if (!x.equals(other.x))
		return false;
	if (y == null) {
		if (other.y != null)
			return false;
	} else if (!y.equals(other.y))
		return false;
	if (z == null) {
		if (other.z != null)
			return false;
	} else if (!z.equals(other.z))
		return false;
	return true;
}

//subtraction of a point
public Point3D subtraction(Point3D a) {
	Coordinate subX = new Coordinate (a.x.subtract(this.x));
	Coordinate subY = new Coordinate (a.y.subtract(this.y));
	Coordinate subZ = new Coordinate (a.z.subtract(this.z));
	Point3D s=new Point3D(subX,subY,subZ);
	return s;	
}

//squared distance
public double squareDistance(Point3D d,Point3D f) {
	Coordinate subX = new Coordinate (f.x.subtract(d.x));
	Coordinate subY = new Coordinate (f.y.subtract(d.y));
	Coordinate subZ = new Coordinate (f.z.subtract(d.z));
	return (Math.pow(subX.get(),2)+Math.pow(subY.get(),2)+Math.pow(subZ.get(),2));
}
//distance
 public double distance(Point3D q,Point3D p) 
 {
	double sqDistance=squareDistance(q,p);
	return (Math.sqrt(sqDistance));
}
 //addition of a point
public Point3D addition (Point3D a) 
{
	Coordinate addX = new Coordinate (this.x.add(a.x));
	Coordinate addY = new Coordinate (this.y.add(a.y));
	Coordinate addZ = new Coordinate (this.z.add(a.z));
	Point3D s = new Point3D (addX,addY,addZ);
	return s;
	
}
}
