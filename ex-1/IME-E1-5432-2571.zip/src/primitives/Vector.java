package primitives;

public class Vector {
	
Point3D pd;


//constructors
public static Vector ZeroVec = new Vector(Point3D.zeroPd);
public Vector(Point3D p) {
	if (p == null )
		throw new IllegalArgumentException("p null");
	this.pd = p;
}

public Vector(Vector v) {
	validate(v);
	pd=v.pd;
}
//getters
public Point3D getPd() {
	return pd;
}

void validate(Vector v) {
	if (v==null || v.getPd()==null || v.equals(ZeroVec))
		throw new IllegalArgumentException("vector zero");
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Vector other = (Vector) obj;
	if (pd == null) {
		if (other.pd != null)
			return false;
	} else if (!pd.equals(other.pd))
		return false;
	return true;
}

@Override
public String toString() {
	return "Vector [vec=" + pd + "]";
}
//addition of vectors
public Vector addition(Vector a,Vector b) {
	validate(a);
	validate(b);
	Point3D add =b.pd.addition(a.pd);
	return new Vector(add);
	
}
//subtraction of vectors
public Vector subtraction(Vector a,Vector b) {
	Point3D p = b.pd.subtraction(a.pd);
	
	return new Vector(p);
}

//scalarization of a vector
public Vector Scaling(Vector a,double t) {
	validate(a);
	Coordinate x=new Coordinate(a.pd.x.scale(t));
	Coordinate y=new Coordinate(a.pd.y.scale(t));
	Coordinate z=new Coordinate(a.pd.z.scale(t));
	Point3D p= new Point3D(x,y,z);
	return new Vector(p);
	 
}
//Dot Product multiplication
public double dotProduct(Vector a,Vector b) {
	validate(a);
	validate(b);
	Coordinate x=new Coordinate(a.pd.x.multiply(b.pd.x));
	Coordinate y=new Coordinate(a.pd.y.multiply(b.pd.y));
	Coordinate z=new Coordinate(a.pd.z.multiply(b.pd.z));
	double sum=((x.get()+y.get()+z.get()));
	return sum;
}
//Cross Product multiplication
public Vector crossProduct(Vector a,Vector b) {
	validate(a);
	validate(b);
	Coordinate x=new Coordinate(a.pd.y.multiply(b.pd.z).subtract(a.pd.z.multiply(b.pd.y)));
	Coordinate y=new Coordinate(a.pd.z.multiply(b.pd.x).subtract(a.pd.x.multiply(b.pd.z)));
	Coordinate z=new Coordinate(a.pd.x.multiply(b.pd.y).subtract(a.pd.y.multiply(b.pd.x)));
	Point3D p=new Point3D(x,y,z);
	Vector v=new Vector(p);
	return v;
}
//Square length of vector 
public double squareLength(Vector a) {
	validate(a);
	Coordinate x=new Coordinate(a.pd.x.multiply(a.pd.x));
	Coordinate y=new Coordinate(a.pd.y.multiply(a.pd.y));
	Coordinate z=new Coordinate(a.pd.z.multiply(a.pd.z));
	double sum=((x.get()+y.get()+z.get()));
	return sum;
	
}
//length of vector
public double length(Vector a) {
	validate(a);
	double l=squareLength(a);
	return(Math.sqrt(l));
}
//Normalize vector to a new one
 public void normal(Vector a) {
	 validate(a);
	double l=length(a);
	Vector v=Scaling(a,1/l);
	a=v;
}
 //Normalize vector
public Vector Normal(Vector b) {
	validate(b);
	
	double l=length(b);
	Vector v=Scaling(b,1/l);
	return v;
}

}






