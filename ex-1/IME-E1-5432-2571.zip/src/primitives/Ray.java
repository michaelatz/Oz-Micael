package primitives;

public class Ray {
Point3D p;
Vector v;
//constructors
public Ray(Vector vec, Point3D p) {
	
	this.v = v.Normal(v);
	this.p = p;
}

public Ray(Ray r) {
	p=r.p;
	v=r.v;
}



//getters
public Point3D getA() {
	return p;
}

public Vector getT() {
	return v;
}
@Override
public String toString() {
	return "Ray [" + p + ", " + v + "]";
}

@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Ray other = (Ray) obj;
	if (p == null) {
		if (other.p != null)
			return false;
	} else if (!p.equals(other.p))
		return false;
	if (v == null) {
		if (other.v != null)
			return false;
	} else if (!v.equals(other.v))
		return false;
	return true;
}


}
