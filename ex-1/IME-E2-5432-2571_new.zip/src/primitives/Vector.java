
package primitives;

public class Vector {
	private Point3D head;

	// ***************** Constructors ********************** //
	/**
	 * Constructs a Vector by its head
	 * 
	 * @param head of the vector
	 */
	public Vector(Point3D head) {
		if (head.equals(Point3D.ZERO)) {
			throw new IllegalArgumentException("Vector zero is illegal");
		}
		this.head = head;
	}

	/**
	 * Constructs a Vector by coordinates of its head
	 * 
	 * @param x coordinate value
	 * @param y coordinate value
	 * @param z coordinate value
	 */
	public Vector(double x, double y, double z) {
		this.head = new Point3D(new Coordinate(x), new Coordinate(y), new Coordinate(z));
		if (head.equals(Point3D.ZERO)) {
			throw new IllegalArgumentException("Vector zero is illegal");
		}
	}

	/**
	 * Copy constructor
	 * 
	 * @param vector
	 */
	public Vector(Vector vector) {
		this.head = vector.head;
	}

	// ***************** Getters/Setters ********************** //
	/**
	 * Vector head point getter
	 * 
	 * @return the head point
	 */
	public Point3D getHead() {
		return head;
	}

	// ***************** Administration ******************** //
	@Override
	public String toString() {
		try {
			return head.toString();
		} catch (NullPointerException e) {
			return "Empty";
		}

	}

	@Override
	public boolean equals(Object other) {

		if (head.equals(((Vector) other).getHead())) {
			return true;
		}
		return false;
	}

	// ***************** Operations ******************** //
	/**
	 * Adding function
	 * 
	 * @param a
	 * @return Vector
	 */
	public Vector add(Vector a) {
		Point3D temp;
		Vector vec;
		temp = new Point3D(this.head.getX().add(a.getHead().getX()), this.head.getY().add(a.getHead().getY()),
				this.head.getZ().add(a.getHead().getZ()));
		vec = new Vector(temp);
		return vec;
	}

	/**
	 * Subtraction function
	 * 
	 * @param a
	 * @return Vector
	 */
	public Vector subtract(Vector a) {
		Point3D temp;
		Vector vec;
		temp = new Point3D(this.head.getX().subtract(a.getHead().getX()), this.head.getY().subtract(a.getHead().getY()),
				this.head.getZ().subtract(a.getHead().getZ()));
		vec = new Vector(temp);
		return vec;
	}

	/**
	 * Scalar multiplication
	 * 
	 * @param num
	 * @return Vector
	 */
	public Vector scale(double num) {
		Point3D temp;
		Vector vec;
		temp = new Point3D(this.head.getX().scale(num), this.head.getY().scale(num), this.head.getZ().scale(num));
		vec = new Vector(temp);
		return vec;
	}

	/**
	 * Calculate dot product between the vector and other vector
	 * 
	 * @param other 2nd vector
	 * @return dot product result
	 */

	public double dotProduct(Vector other) {
		double x1 = this.head.getX().get();
		double y1 = this.head.getY().get();
		double z1 = this.head.getZ().get();

		double x2 = other.head.getX().get();
		double y2 = other.head.getY().get();
		double z2 = other.head.getZ().get();

		return x1 * x2 + y1 * y2 + z1 * z2;
	}

	/**
	 * Calculate cross product s1=Ax*Bz-Az*By s2=Az*Bx-Ax*Bz s3=Ax*BY-Ay*Bx
	 * 
	 * @param a
	 * @return Vector
	 */

	public Vector crossProduct(Vector other) {
		double x1 = this.head.getX().get();
		double y1 = this.head.getY().get();
		double z1 = this.head.getZ().get();

		double x2 = other.head.getX().get();
		double y2 = other.head.getY().get();
		double z2 = other.head.getZ().get();

		return new Vector(y1 * z2 - y2 * z1, z1 * x2 - z2 * x1, x1 * y2 - x2 * y1);
	}

	/**
	 * Calculate length square (X^2+Y^2+Z^2)
	 * 
	 * @return double
	 */

	public double length2() {
		double x = this.head.getX().get();
		double y = this.head.getY().get();
		double z = this.head.getZ().get();

		return x * x + y * y + z * z;
	}

	/**
	 * Calculate the length root of(X^2+Y^2+Z^2)
	 * 
	 * @return double
	 */
	public double length() {
		return Math.sqrt(length2());
	}

	/**
	 * Normal the vector vector / length Change the vector
	 */

	public Vector normal() {
		double l = length();
		double x = this.head.getX().get();
		double y = this.head.getY().get();
		double z = this.head.getZ().get();
		this.head = new Point3D(x / l, y / l, z / l);
		return this;
	}

	/**
	 * Normal the vector vector / length return new vector
	 * 
	 * @return Vector
	 */
	public Vector normalization() {
		return new Vector(this).normal();
	}

}
