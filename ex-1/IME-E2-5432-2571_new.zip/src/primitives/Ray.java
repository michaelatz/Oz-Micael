package primitives;

public class Ray {
	public Point3D p;
	public Vector v;

	/****** constructors ******/
	public Ray(Vector vec, Point3D p) {

		this.v = vec.normalization();
		this.p = p;
	}

	public Ray(Ray r) {
		p = r.p;
		v = r.v;
	}

	/****** getters ******/
	public Point3D getP() {
		return p;
	}

	public Vector getV() {
		return v;
	}

	/************** administration **************/
	@Override
	public String toString() {
		return "Ray [" + p + ", " + v + "]";
	}

	@Override
	public boolean equals(Object other) {
		if (p.equals(other) == true) {
			if (v.equals(other) == true) {
				return true;
			}
		}
		return false;
	}

}
