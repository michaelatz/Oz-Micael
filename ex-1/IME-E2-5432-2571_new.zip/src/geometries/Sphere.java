package geometries;

import primitives.Point3D;
import primitives.Vector;

public class Sphere extends RadialGeometry {
	Point3D _center;

	/****** constructors *****/
	public Sphere(double _radius) {
		super(_radius);
	}

	public Sphere(double _radius, Point3D _center) {
		super(_radius);
		this._center = _center;
	}

	/****** getter *****/
	public Point3D get_center() {
		return _center;
	}

	/************** operations **************/
	/**
	 * vector normal
	 * 
	 * @param p
	 * @return normal
	 */

	public Vector getNormal(Point3D p) {
		Vector v = new Vector(p.subtract(_center));
		return v.normalization();
	}

}
