package geometries;

import primitives.Point3D;
import primitives.*;

public interface Geometry {
	/**
	 * Normalization of a vector
	 * 
	 * @param a
	 * @return abstract (normal)
	 */
	public abstract Vector getNormal();
	
}
