package geometries;

import primitives.*;

public class Tube extends RadialGeometry {
	protected Ray _axisRay;

	/********* constructors *********/
	/**
	 * 
	 * @param radius
	 * @param axisRay
	 */
	public Tube(double radius, Ray axisRay) {
		super(radius);
		this._axisRay = new Ray(axisRay);
	}

	public Tube(Tube tube) {
		super(tube._radius);
		this._axisRay = new Ray(tube._axisRay);
	}

	/********* getter *********/
	public Ray get_axisRay() {
		return _axisRay;
	}

	/************** operations **************/
	public Vector getNormal(Point3D p) {
		Point3D p0 = _axisRay.getP();
		Vector v = _axisRay.getV();
		Vector u = p.subtract(p0);// Vector from p0 to p
		double t = v.dotProduct(u);// size of projection of vector u on the ray, point on the ray and plane
					// crossing p and orthogonal to the ray
	
		Point3D o;
		if (t==0)
			o = p0;
		else
			o = p0.add(v.scale(t));
		return p.subtract(o).normalization();

	}

}
