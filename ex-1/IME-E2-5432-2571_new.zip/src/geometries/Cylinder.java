package geometries;

import primitives.*;

public class Cylinder extends Tube {
	private double height;

	/********* constructors *********/
	/**
	 * Regular constructor
	 * 
	 * @param radius
	 * @param axisRay
	 * @param height
	 */
	public Cylinder(double radius, Ray axisRay, double height) {
		super(radius, axisRay);
		this.height = height;
	}

	public Cylinder(Cylinder cylinder) {
		super(cylinder._radius, cylinder._axisRay);
		this.height = cylinder.height;
	}

	/********* getter *********/
	/**
	 * @return height
	 */
	public double getHeight() {
		return height;
	}

	/************** operations **************/
	/**
	 * get normal function
	 * 
	 * @param Point3D
	 * @return getNormal
	 */
	public Vector getNormal(Point3D poi) {
		Point3D p1 = _axisRay.getP();
		Vector v = _axisRay.getV();
		Vector u = poi.subtract(p1);//vector from p1 to poi
		double t=v.dotProduct(u);//size of projection of vector u on the ray, point on the ray and plane crossing P and orthogonal to the ray  
		if(t==0||(t-this.height)==0)
			return v;
		return poi.subtract(p1.add(v.scale(t))).normalization();
	}
}