package geometries;

import java.util.List;

import java.util.Arrays;

import static primitives.Util.*;
import primitives.*;

public class Polygon implements Geometry {
	public List<Point3D> _points;
	public Plane _plane;

	/******* constructor *********/

	public Polygon(Point3D... points) {

		if (points.length < 3)
			throw new IllegalArgumentException("Polygon must have at least 3 vertices");
		Point3D p1 = points[0];
		Point3D p2 = points[1];
		Point3D p3 = points[2];
		_plane = new Plane(p1, p2, p3);
		Vector n = _plane.getNormal();
		for (int i = 3; i < points.length; i++)
			if (!isZero(p1.subtract(points[i]).dotProduct(n)))
				throw new IllegalArgumentException("Polygon's vertices must resize in the same plane");
		_points = Arrays.asList(points);
	}

	/************** operations **************/
	/**
	 * getNormal
	 */
	@Override
	public Vector getNormal() {

		return _plane.getNormal();
	}

}