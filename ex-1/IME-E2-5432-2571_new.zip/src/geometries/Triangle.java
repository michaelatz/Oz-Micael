package geometries;

import java.util.List;

import primitives.*;

public class Triangle extends Polygon {
	/***************** Constructors **********************/
	/**
	 * @param points
	 * @param plane
	 */
	public Triangle(Point3D... points) {
		super(points);
	}



	/************** operations **************/
	/**
	 * get normal function
	 * 
	 * @param Point3D
	 * @return normal
	 */

	public Vector getNormal() {
		return this._plane.getNormal();
	}
}