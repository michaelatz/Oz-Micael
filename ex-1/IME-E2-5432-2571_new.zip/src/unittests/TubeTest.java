package unittests;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;

import geometries.*;
import primitives.*;

public class TubeTest {

	@Test
	/**
	 * Test method for {@link geometries.Cylinder#getNormal(primitives.Point3D)}.
	 */
	public void getNormaltest() {
		try {
			Point3D p1 = new Point3D(0.0, 0.0, 0.0);
			Point3D p2 = new Point3D(1.0, 0.0, 0.0);
			Point3D p3 = new Point3D(3.0, 1.0, 0.0);
			Vector vec = new Vector(p2);
			Ray ray = new Ray(vec, p1);
			double r = 1.0;
			Tube tube = new Tube(r, ray);
			Vector actual = tube.getNormal(p3);
			Vector expected = new Vector(0.0, 1.0, 0.0);
			Assert.assertEquals(expected, actual);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("getNormaltest unxpected exception:" + e);
		}
	}
}
