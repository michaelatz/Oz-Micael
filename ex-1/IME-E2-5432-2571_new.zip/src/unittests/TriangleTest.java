package unittests;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;

import geometries.*;
import primitives.*;

public class TriangleTest {

	/**
	 * Test method for {@link geometries.Triangle#getNormal(primitives.Point3D)}.
	 */
	@Test
	public void getNormaltest() {
		try {
			Point3D p1 = new Point3D(1.0, 0.0, 0.0);
			Point3D p2 = new Point3D(1.0, 1.0, 1.0);
			Point3D p3 = new Point3D(0.0, 1.0,1.0);
			Triangle tri = new Triangle(p1, p2, p3);
			Vector actual = tri.getNormal();
			Vector expected = new Vector(0.0, -1.0, 1.0);
			Assert.assertEquals(expected, actual);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("getNormaltest unxpected exception:" + e);
		}
	}

}
