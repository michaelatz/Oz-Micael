package unittests;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;
import geometries.*;
import primitives.*;

public class PlaneTest {

	@Test
	/**
	 * Test method for {@link geometries.Plane#getNormal(primitives.Point3D)}.
	 */
	public void getNormaltest() {
		try {
			Point3D p1 = new Point3D(1.0, 0.0, 0.0);
			Point3D p2 = new Point3D(1.0, 1.0, 1.0);
			Point3D p3 = new Point3D(0.0, 1.0, 1.0);
			Plane plane = new Plane(p1, p2, p3);
			Vector actual = plane.getNormal();
			Vector expected = new Vector(0.0, -1.0, 1.0);
			Assert.assertEquals(expected, actual);
		} catch (Exception e) {
			Assert.fail("getNormaltest unxpected exception:" + e);
		}
	}

}
