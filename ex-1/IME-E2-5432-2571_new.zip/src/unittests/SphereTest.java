package unittests;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;

import geometries.*;
import primitives.*;

public class SphereTest {

	@Test
	/**
	 * Test method for {@link geometries.Sphere#getNormal(primitives.Point3D)}.
	 */
	public void getNormaltest() {
		try {
			Point3D p1 = new Point3D(3.0,0.0,0.0);
			Point3D c = new Point3D(0.0,0.0, 0.0);
			double r = 3.0;
			Sphere sph = new Sphere(r, c);
			Vector actual = sph.getNormal(p1);
			Vector expected = new Vector(1.0, 0.0,0.0);
			Assert.assertEquals(expected, actual);
		} catch (Exception e) {
			Assert.fail("getNormaltest unxpected exception:" + e);
		}
	}
}
