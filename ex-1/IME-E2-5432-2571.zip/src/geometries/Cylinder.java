package geometries;

import primitives.*;

public class Cylinder extends Tube {
	private double height;

	/********* constructors *********/
	/**
	 * Regular constructor
	 * 
	 * @param radius
	 * @param axisRay
	 * @param height
	 */
	public Cylinder(double radius, Ray axisRay, double height) {
		super(radius, axisRay);
		this.height = height;
	}

	public Cylinder(Cylinder cylinder) {
		super(cylinder._radius, cylinder._axisRay);
		this.height = cylinder.height;
	}

	/********* getter *********/
	/**
	 * @return height
	 */
	public double getHeight() {
		return height;
	}

	/************** operations **************/
	/**
	 * get normal function
	 * 
	 * @param Point3D
	 * @return getNormal
	 */
	public Vector getNormal(Point3D point) {
		Point3D poi1 = new Point3D(_axisRay.p);
		Vector vec = new Vector(_axisRay.v.scale(height));
		Point3D poi2 = new Point3D(vec.pd.addition(_axisRay.p));
		if (poi1.distance(point) < _radius || poi2.distance(point) < _radius) {
			return _axisRay.v;
		}
		if (poi1.distance(point) > _radius || poi2.distance(point) > _radius) {
			return (super.getNormal(point));
		}
		throw new IllegalArgumentException("not alowded");

	}
}