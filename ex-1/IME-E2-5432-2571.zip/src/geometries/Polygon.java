package geometries;

import java.util.List;
import java.util.ArrayList;

import static primitives.Util.*;
import primitives.*;

public class Polygon implements Geometry {
	public List<Point3D> _points;
	public Plane _plane;

	/******* constructor *********/

	public Polygon(Point3D... points) {

		_points = new ArrayList<>();
		_plane = new Plane(points[0], points[1], points[2]);
		Vector normal = _plane.getNormal();
		for (int i = 0; i < points.length; i++) {
			_points.add(points[i]);
			if (i < 2 && i != 0 && !isZero(points[0].subtraction(points[i]).dotProduct(normal)))
				throw new IllegalArgumentException();

		}

	}

	public Polygon(List<Point3D> points, Plane plane) {
		this._plane = plane;
		this._points = points;

	}

	/************** operations **************/
	/**
	 * getNormal
	 */
	@Override
	public Vector getNormal() {

		return _plane.getNormal();
	}

}