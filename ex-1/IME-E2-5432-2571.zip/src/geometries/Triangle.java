package geometries;

import java.util.List;

import primitives.*;

public class Triangle extends Polygon {
	/***************** Constructors **********************/
	/**
	 * @param points
	 * @param plane
	 */
	public Triangle(Point3D... points) {
		super(points);
	}

	/**
	 * copy constructor
	 * 
	 * @param triangle
	 */
	public Triangle(Triangle triangle) {
		super(triangle._points, triangle._plane);
	}

	/************** operations **************/
	/**
	 * get normal function
	 * 
	 * @param Point3D
	 * @return normal
	 */

	public Vector getNormal() {
		return this._plane.getNormal();
	}
}