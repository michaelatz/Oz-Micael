package geometries;

import primitives.Point3D;
import primitives.Ray;
import primitives.Vector;

public class Tube extends RadialGeometry {
	protected Ray _axisRay;

	/********* constructors *********/
	/**
	 * 
	 * @param radius
	 * @param axisRay
	 */
	public Tube(double radius, Ray axisRay) {
		super(radius);
		this._axisRay = new Ray(axisRay);
	}

	public Tube(Tube tube) {
		super(tube._radius);
		this._axisRay = new Ray(tube._axisRay);
	}

	/********* getter *********/
	public Ray get_axisRay() {
		return _axisRay;
	}

	/************** operations **************/
	/**
	 * get normal function: d= distance between our point to the ray. h= height of our
	 * "jump" by Pythagorean theorem. vec= the direction vector. q= the second point
	 * w=vector normal.
	 * 
	 * @param a
	 * @return normal
	 */

	public Vector getNormal(Point3D poi) {
		double d = (poi.distance(_axisRay.p));
		double h = (d * d) - (_radius * _radius);
		Vector vec = new Vector(_axisRay.v.scale(h));
		Point3D q = new Point3D(vec.pd.addition(poi));
		Vector w = new Vector(poi.subtraction(q));
		return w.Normal();
	}

}
