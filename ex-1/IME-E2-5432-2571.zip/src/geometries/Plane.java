package geometries;

import primitives.*;
import primitives.Vector;

public class Plane implements Geometry {
	Point3D _p;
	Vector _normal;

	/****** constructor ******/
	public Plane(Point3D _p1, Point3D _p2, Point3D _p3) {
		this._p = _p1;
		this._normal = _p2.subtraction(_p1).crossProduct(_p3.subtraction(_p1));
	}

	public Plane(Point3D _p, Vector _normal) {
		this._p = _p;
		this._normal = _normal.Normal();
	}

	/**
	 * getNormal
	 * 
	 * @return normal
	 */

	public Vector getNormal() {
		return _normal;
	}

}
