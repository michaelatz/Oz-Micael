package primitives;

public class Point3D {

	Coordinate x;
	Coordinate y;
	Coordinate z;

	/************** constructors **************/
	public Point3D(Point3D a) {
		x = a.x;
		y = a.y;
		z = a.z;
	}

	public Point3D(Coordinate x, Coordinate y, Coordinate z) {
		super();
		this.x = x;
		this.y = y;
		this.z = z;
	}

	/************** getters **************/
	public Coordinate getX() {
		return x;
	}

	public Coordinate getY() {
		return y;
	}

	public Coordinate getZ() {
		return z;
	}

	/************** admin **************/
	@Override
	public String toString() {
		return "Point3D [x=" + x + ", y=" + y + ", z=" + z + "]";
	}

	@Override
	public boolean equals(Object other) {
		if (this.getClass() == other.getClass()) {
			Point3D obj = (Point3D) other;
			if (x.equals(obj.getX()) && y.equals(obj.getY()) && z.equals(obj.getZ())) {

				return true;
			}
		}
		return false;
	}

	/************** operations **************/
	/**
	 * subtraction of a point
	 * 
	 * @param a
	 * @return vector from
	 */
	public Vector subtraction(Point3D a) {
		Coordinate subX = new Coordinate(this.x.subtract(a.x));
		Coordinate subY = new Coordinate(this.y.subtract(a.y));
		Coordinate subZ = new Coordinate(this.z.subtract(a.z));
		Point3D p = new Point3D(subX, subY, subZ);
		Vector v = new Vector(p);
		return v;
	}

	/**
	 * square distance
	 * 
	 * @param d
	 * @param f
	 * @return double square distance between d,f
	 */
	public double squareDistance(Point3D d) {
		Coordinate x = new Coordinate(this.x.subtract(d.x));
		Coordinate y = new Coordinate(this.y.subtract(d.y));
		Coordinate z = new Coordinate(this.z.subtract(d.z));
		x = x.multiply(x);
		y = y.multiply(y);
		z = z.multiply(z);
		double sum = (x._coord + y._coord + z._coord);
		return sum;
	}

	/**
	 * distance
	 * 
	 * @param q
	 * @param p
	 * @return double distance between q,p
	 */
	public double distance(Point3D q) {
		double sqDistance = this.squareDistance(q);
		return (Math.sqrt(sqDistance));
	}

	/**
	 * addition of a point
	 * 
	 * @param a
	 * @return new point
	 */
	public Point3D addition(Point3D a) {
		Coordinate addX = new Coordinate(this.x.add(a.x));
		Coordinate addY = new Coordinate(this.y.add(a.y));
		Coordinate addZ = new Coordinate(this.z.add(a.z));
		Point3D s = new Point3D(addX, addY, addZ);
		return s;

	}
}
