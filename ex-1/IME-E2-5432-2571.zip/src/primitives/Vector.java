package primitives;

public class Vector {

	public Point3D pd;

	public static Point3D ZeroVec = new Point3D(Coordinate.ZERO, Coordinate.ZERO, Coordinate.ZERO);

	/************ constructors ************/

	public Vector(Point3D p) {
		if (p.equals(ZeroVec))
			throw new IllegalArgumentException(" vector zero");
		this.pd = p;
	}

	public Vector(Vector v) {

		pd = v.pd;
	}

	/************ getters ************/

	public Point3D getPd() {
		return pd;
	}

	/************** admin **************/
	@Override
	public boolean equals(Object other) {

		if (pd.equals(((Vector) other).getPd())) {
			return true;
		}
		return false;
	}

	@Override
	public String toString() {
		return "Vector[vec=" + pd + "]";
	}

	/************** operations **************/
	/**
	 * addition of vectors
	 * 
	 * @param a
	 * @param b
	 * @return vector a+b
	 */

	public Vector add(Vector a) {
		Point3D add = pd.addition(a.pd);
		return new Vector(add);

	}

	/**
	 * subtraction of vectors
	 * 
	 * @param a
	 * @param b
	 * @return vector a-b
	 */
	public Vector subtract(Vector a) {
		Vector p = pd.subtraction(a.pd);

		return p;
	}

	/**
	 * scalarization of a vector
	 * 
	 * @param a
	 * @param t
	 * @return vector a*(double t)
	 */
	public Vector scale(double t) {

		Coordinate x = new Coordinate(pd.x.scale(t));
		Coordinate y = new Coordinate(pd.y.scale(t));
		Coordinate z = new Coordinate(pd.z.scale(t));
		Point3D p = new Point3D(x, y, z);
		return new Vector(p);

	}

	/**
	 * Dot Product multiplication
	 * 
	 * @param other
	 * @return vector other*the current vector
	 */
	public double dotProduct(Vector other) {

		Coordinate x;
		Coordinate y;
		Coordinate z;
		x = pd.getX().multiply(other.getPd().getX());
		y = pd.getY().multiply(other.getPd().getY());
		z = pd.getZ().multiply(other.getPd().getZ());
		double sum = ((x.get() + y.get() + z.get()));
		return sum;
	}

	/**
	 * Cross Product multiplication
	 * 
	 * @param other
	 * @return vector otherXhe current vector
	 */
	public Vector crossProduct(Vector other) {
		Point3D p;
		Vector b;
		Coordinate x;
		Coordinate y;
		Coordinate z;
		x = this.getPd().getZ().multiply(other.getPd().getY()).subtract(pd.getY().multiply(other.getPd().getZ()));
		y = this.getPd().getX().multiply(other.getPd().getZ()).subtract(pd.getZ().multiply(other.getPd().getX()));
		z = this.getPd().getY().multiply(other.getPd().getX()).subtract(pd.getX().multiply(other.getPd().getY()));
		p = new Point3D(x, y, z);
		b = new Vector(p);
		return b;
	}

	/**
	 * Square length of vector
	 * 
	 * @param a
	 * @return double square length of vector a
	 */
	public double squareLength(Vector a) {

		Coordinate x = new Coordinate(a.pd.x.multiply(a.pd.x));
		Coordinate y = new Coordinate(a.pd.y.multiply(a.pd.y));
		Coordinate z = new Coordinate(a.pd.z.multiply(a.pd.z));
		double sum = ((x.get() + y.get() + z.get()));
		return sum;

	}

	/**
	 * length of vector
	 * 
	 * @param a
	 * @return double length of vector
	 */
	public double length(Vector a) {

		double l = squareLength(a);
		return (Math.sqrt(l));
	}

	/**
	 * Normalize vector to a new one
	 * 
	 * @param a
	 */
	public void newNormal() {
		double temp;
		Vector OtherVec = new Vector(this.pd);
		temp = 1 / this.length(OtherVec);
		OtherVec = this.scale(temp);
		this.pd = OtherVec.pd;
	}

	/**
	 * Normalize vector
	 * 
	 * @param b
	 * @return normalize vector of b
	 */
	public Vector Normal() {
		Vector OtherVec = new Vector(this.pd);
		OtherVec.newNormal();
		return OtherVec;
	}

}
