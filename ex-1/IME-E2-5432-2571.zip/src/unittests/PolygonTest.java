package unittests;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;

import geometries.*;
import primitives.*;

public class PolygonTest {

	/**
	 * get Normal test
	 */
	@Test
	public void getNormaltest() {
		try {
			Point3D p1 = new Point3D(new Coordinate(1.0), new Coordinate(0.0), new Coordinate(0.0));
			Point3D p2 = new Point3D(new Coordinate(1.0), new Coordinate(1.0), new Coordinate(1.0));
			Point3D p3 = new Point3D(new Coordinate(0.0), new Coordinate(1.0), new Coordinate(1.0));
			Point3D p4 = new Point3D(new Coordinate(2.0), new Coordinate(1.0), new Coordinate(1.0));
			Polygon polygon = new Polygon(p1, p2, p3, p4);
			Vector actual = polygon.getNormal();
			Vector expected = new Vector(new Point3D(new Coordinate(0.0), new Coordinate(1.0), new Coordinate(-1.0)));
			Assert.assertEquals(expected, actual);
		} catch (Exception e) {
			Assert.fail("getNormaltest unxpected exception:" + e);
		}
	}

}
