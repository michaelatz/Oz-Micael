package unittests;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;

import primitives.*;

public class VectorTest {

	/**
	 * test Vector Zero
	 */
	@Test
	public void testVectorZero() {

		try {
			Point3D p = new Point3D(Coordinate.ZERO, Coordinate.ZERO, Coordinate.ZERO);
			Vector myVector = new Vector(new Point3D(Coordinate.ZERO, Coordinate.ZERO, Coordinate.ZERO));
			Assert.assertNotEquals(myVector, p);
			Assert.fail("Test failed should throw excepion");
		} catch (IllegalArgumentException e) {
			Assert.assertTrue("Test PASS  throw excepion in case of Zero", true);

		}

	}

	/**
	 * test Addition
	 */
	@Test
	public void testAddition() {
		try {
			Vector myVector = new Vector(new Point3D(new Coordinate(1.0), new Coordinate(2.0), new Coordinate(3.0)));
			Vector other = new Vector(new Point3D(new Coordinate(1.0), new Coordinate(1.0), new Coordinate(1.0)));
			Vector expected = new Vector(new Point3D(new Coordinate(2.0), new Coordinate(3.0), new Coordinate(4.0)));
			Vector actual = myVector.add(other);
			Assert.assertEquals(expected, actual);

		} catch (Exception e) {
			Assert.fail("testAddition unxpected exception:" + e);
		}

	}

	/**
	 * test Subtract
	 */
	@Test
	public void testSubtract() {
		try {
			Vector myVector = new Vector(new Point3D(new Coordinate(1.0), new Coordinate(2.0), new Coordinate(3.0)));
			Vector other = new Vector(new Point3D(new Coordinate(1.0), new Coordinate(1.0), new Coordinate(1.0)));
			Vector expected = new Vector(new Point3D(new Coordinate(0.0), new Coordinate(1.0), new Coordinate(2.0)));
			Vector actual = myVector.subtract(other);
			Assert.assertEquals(expected, actual);

		} catch (Exception e) {
			Assert.fail("test Subtract fail unxpected exception:" + e);
		}

	}

	/**
	 * test Scale
	 */
	@Test
	public void testScale() {
		try {
			Vector myVector = new Vector(new Point3D(new Coordinate(1.0), new Coordinate(2.0), new Coordinate(3.0)));
			double a = 2.0;
			Vector expected = new Vector(new Point3D(new Coordinate(2.0), new Coordinate(4.0), new Coordinate(6.0)));
			Vector actual = myVector.scale(a);
			Assert.assertEquals(expected, actual);

		} catch (Exception e) {
			Assert.fail("test Scale fail unxpected exception:" + e);
		}
	}

	/**
	 * test DotProduct
	 */
	@Test
	public void testDotProduct() {
		try {
			Vector myVector = new Vector(new Point3D(new Coordinate(1.0), new Coordinate(2.0), new Coordinate(3.0)));
			Vector other = new Vector(new Point3D(new Coordinate(1.0), new Coordinate(1.0), new Coordinate(1.0)));
			double expected = 6.0;
			double actual = myVector.dotProduct(other);
			Assert.assertEquals(expected, actual, 0.0);
		} catch (Exception e) {
			Assert.fail("test DotProduct fail unxpected exception:" + e);
		}
	}

	/**
	 * test CrossProduct
	 */
	@Test
	public void testCrossProduct() {
		try {
			Vector myVector = new Vector(new Point3D(new Coordinate(1.0), new Coordinate(2.0), new Coordinate(3.0)));
			Vector other = new Vector(new Point3D(new Coordinate(1.0), new Coordinate(1.0), new Coordinate(1.0)));
			Vector expected = new Vector(new Point3D(new Coordinate(1), new Coordinate(-2), new Coordinate(1)));

			Vector result = myVector.crossProduct(other);
			Assert.assertEquals(expected, result);
		} catch (Exception e) {
			Assert.fail("test CrossProduct fail unxpected exception:" + e);
		}
	}

	/**
	 * test normalize a vector
	 */
	@Test
	public void testNormal() {
		try {
			Vector myVector = new Vector(new Point3D(new Coordinate(1.0), new Coordinate(2.0), new Coordinate(2.0)));
			Vector expected = new Vector(new Point3D(new Coordinate((double) 1 / 3), new Coordinate((double) 2 / 3),
					new Coordinate((double) 2 / 3)));

			Vector result = myVector.Normal();
			Assert.assertEquals(expected, result);
		} catch (Exception e) {
			Assert.fail("test CrossProduct fail unxpected exception:" + e);
		}
	}
}
