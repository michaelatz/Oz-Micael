package unittests;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;

import geometries.*;
import primitives.*;

public class CylinderTest {

	@Test
	/**
	 * get Normal test-case1
	 */
	public void getNormaltest1() {
		try {
			Point3D p1 = new Point3D(new Coordinate(0.0), new Coordinate(0.0), new Coordinate(0.0));
			Point3D p2 = new Point3D(new Coordinate(1.0), new Coordinate(2.0), new Coordinate(2.0));
			Point3D p3 = new Point3D(new Coordinate(3.0), new Coordinate(5.0), new Coordinate(5.0));
			Vector vec = new Vector(p2);
			Ray ray = new Ray(vec, p1);
			double h = 5.0;
			double r = 3.0;
			Cylinder cy = new Cylinder(r, ray, h);
			Vector actual = cy.getNormal(p3);
			Vector expected = new Vector(
					new Point3D(new Coordinate((1 / 3.0)), new Coordinate((2 / 3.0)), new Coordinate((2 / 3.0))));
			Assert.assertEquals(expected, actual);
		} catch (Exception e) {
			Assert.fail("getNormaltest unxpected exception:" + e);
		}
	}

	@Test
	/**
	 * get Normal test:case2
	 */
	public void getNormaltest2() {
		try {
			Point3D p1 = new Point3D(new Coordinate(0.0), new Coordinate(0.0), new Coordinate(0.0));
			Point3D p2 = new Point3D(new Coordinate(1.0), new Coordinate(2.0), new Coordinate(2.0));
			Point3D p3 = new Point3D(new Coordinate(5.0), new Coordinate(10.0), new Coordinate(10.0));
			Vector vec = new Vector(p2);
			Ray ray = new Ray(vec, p1);
			double h = 5.0;
			double r = 3.0;
			Cylinder cy = new Cylinder(r, ray, h);
			Vector actual = cy.getNormal(p3);
			Vector expected = new Vector(
					new Point3D(new Coordinate((-1 / 3.0)), new Coordinate((-2 / 3.0)), new Coordinate((-2 / 3.0))));
			Assert.assertEquals(expected, actual);
		} catch (Exception e) {
			Assert.fail("getNormaltest unxpected exception:" + e);
		}
	}

}
