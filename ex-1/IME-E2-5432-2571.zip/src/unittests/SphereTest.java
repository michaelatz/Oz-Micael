package unittests;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;

import geometries.*;
import primitives.*;

public class SphereTest {

	@Test
	/**
	 * getNormal test
	 */
	public void getNormaltest() {
		try {
			Point3D p1 = new Point3D(new Coordinate(3.0), new Coordinate(0.0), new Coordinate(0.0));
			Point3D c = new Point3D(new Coordinate(0.0), new Coordinate(0.0), new Coordinate(0.0));
			double r = 3.0;
			Sphere sph = new Sphere(r, c);
			Vector actual = sph.getNormal(p1);
			Vector expected = new Vector(new Point3D(new Coordinate(1.0), new Coordinate(0.0), new Coordinate(0.0)));
			Assert.assertEquals(expected, actual);
		} catch (Exception e) {
			Assert.fail("getNormaltest unxpected exception:" + e);
		}
	}
}
