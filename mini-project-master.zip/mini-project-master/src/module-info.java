module targil1 {
	requires junit;
	requires java.desktop;
}